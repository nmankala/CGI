/* tslint:disable */
require("./LandingPage.module.css");
const styles = {
  landingPage: 'landingPage_cadd9f0d',
  container: 'container_cadd9f0d',
  row: 'row_cadd9f0d',
  column: 'column_cadd9f0d',
  'ms-Grid': 'ms-Grid_cadd9f0d',
  title: 'title_cadd9f0d',
  subTitle: 'subTitle_cadd9f0d',
  description: 'description_cadd9f0d',
  button: 'button_cadd9f0d',
  label: 'label_cadd9f0d',
  cbutton: 'cbutton_cadd9f0d',
  ebutton: 'ebutton_cadd9f0d'
};

export default styles;
/* tslint:enable */