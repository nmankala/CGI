/* tslint:disable */
require("./SiteAccess.module.css");
const styles = {
  siteandWf: 'siteandWf_03bed3c2',
  container: 'container_03bed3c2',
  row: 'row_03bed3c2',
  column: 'column_03bed3c2',
  'ms-Grid': 'ms-Grid_03bed3c2',
  title: 'title_03bed3c2',
  subTitle: 'subTitle_03bed3c2',
  description: 'description_03bed3c2',
  button: 'button_03bed3c2',
  label: 'label_03bed3c2',
  heading: 'heading_03bed3c2'
};

export default styles;
/* tslint:enable */