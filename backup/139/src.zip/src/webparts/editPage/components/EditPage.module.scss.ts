/* tslint:disable */
require("./EditPage.module.css");
const styles = {
  editPage: 'editPage_b675a252',
  container: 'container_b675a252',
  row: 'row_b675a252',
  column: 'column_b675a252',
  'ms-Grid': 'ms-Grid_b675a252',
  title: 'title_b675a252',
  subTitle: 'subTitle_b675a252',
  description: 'description_b675a252',
  button: 'button_b675a252',
  label: 'label_b675a252'
};

export default styles;
/* tslint:enable */