import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IEditPageProps {
  description: string;
  context: WebPartContext;
}
