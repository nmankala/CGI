declare const styles: {
    landingPage: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    cbutton: string;
    ebutton: string;
};
export default styles;
//# sourceMappingURL=LandingPage.module.scss.d.ts.map