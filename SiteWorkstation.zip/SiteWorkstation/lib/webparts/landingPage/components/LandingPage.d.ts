import * as React from 'react';
import { ILandingPageProps, ILandingPageState } from './ILandingPageProps';
import "bootstrap/dist/css/bootstrap.min.css";
export default class LandingPage extends React.Component<ILandingPageProps, ILandingPageState> {
    constructor(props: ILandingPageProps, state: ILandingPageState);
    render(): React.ReactElement<ILandingPageProps>;
    buttonChange(change: string): void;
}
//# sourceMappingURL=LandingPage.d.ts.map