import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ISiteAccessWebPartProps {
    description: string;
}
export default class SiteAccessWebPart extends BaseClientSideWebPart<ISiteAccessWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected getSelectedItem(listName: string, Id: any): Promise<any>;
    getParameterByName(name: any, url?: string): string;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SiteAccessWebPart.d.ts.map