import * as React from 'react';
import { IScreeningTestProps } from './IScreeningTestProps';
import { IScreeningTestState } from './IScreeningTestProps';
import "bootstrap/dist/css/bootstrap.min.css";
export default class ScreeningTest extends React.Component<IScreeningTestProps, IScreeningTestState> {
    constructor(props: IScreeningTestProps, state: IScreeningTestState);
    render(): React.ReactElement<IScreeningTestProps>;
    saveItem(): void;
    submitItem(): void;
    check(): boolean;
    resetItem(): void;
    _onChange(ev: any, checked?: boolean): void;
}
//# sourceMappingURL=ScreeningTest.d.ts.map