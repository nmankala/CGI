import * as React from 'react';
import { IScreeningTestProps } from './IScreeningTestProps';
import { IScreeningViewState } from './IScreeningTestProps';
import "bootstrap/dist/css/bootstrap.min.css";
export default class ScreeningTestview extends React.Component<IScreeningTestProps, IScreeningViewState> {
    constructor(props: IScreeningTestProps, state: IScreeningViewState);
    render(): React.ReactElement<IScreeningTestProps>;
    check(st: string): boolean;
    saveItem(): void;
    _onChange(ev: any, checked?: boolean): void;
    _onChange1(ev: any, check: any): void;
    componentDidMount(): void;
}
//# sourceMappingURL=ScreeningView.d.ts.map