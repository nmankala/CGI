import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IScreeningTestWebPartProps {
    description: string;
}
export default class ScreeningTestWebPart extends BaseClientSideWebPart<IScreeningTestWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getSelectedItem(listName: string, Id: any): Promise<any>;
    getParameterByName(name: any, url?: string): string;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ScreeningTestWebPart.d.ts.map