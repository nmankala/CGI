import * as React from 'react';
import { IEditPageProps } from './IEditPageProps';
export interface IDetailsListCompactExampleItem {
    key: number;
    ID: number;
    Name: string;
    Department: string;
    SitetobeAccessed: string;
    MeetingFromTime: string;
    MeetingToTime: Date;
}
export interface IDetailsListCompactExampleState {
    items: IDetailsListCompactExampleItem[];
    selectionDetails: string;
}
export default class CheckIn extends React.Component<IEditPageProps, IDetailsListCompactExampleState> {
    private _selection;
    private _allItems;
    private _columns;
    constructor(props: IEditPageProps);
    render(): JSX.Element;
    private _getSelectionDetails;
    private _onFilter;
    private _onItemInvoked;
    componentDidMount(): void;
}
//# sourceMappingURL=CheckIn.d.ts.map