declare interface IEditPageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EditPageWebPartStrings' {
  const strings: IEditPageWebPartStrings;
  export = strings;
}
