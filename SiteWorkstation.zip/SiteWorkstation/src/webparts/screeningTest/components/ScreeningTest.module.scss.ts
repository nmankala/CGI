/* tslint:disable */
require("./ScreeningTest.module.css");
const styles = {
  screeningTest: 'screeningTest_0313ec34',
  container: 'container_0313ec34',
  row: 'row_0313ec34',
  column: 'column_0313ec34',
  'ms-Grid': 'ms-Grid_0313ec34',
  title: 'title_0313ec34',
  subTitle: 'subTitle_0313ec34',
  description: 'description_0313ec34',
  button: 'button_0313ec34',
  label: 'label_0313ec34'
};

export default styles;
/* tslint:enable */