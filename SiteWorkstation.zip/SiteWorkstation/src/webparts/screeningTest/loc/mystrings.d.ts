declare interface IScreeningTestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ScreeningTestWebPartStrings' {
  const strings: IScreeningTestWebPartStrings;
  export = strings;
}
