declare interface ILandingPageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LandingPageWebPartStrings' {
  const strings: ILandingPageWebPartStrings;
  export = strings;
}
