/* tslint:disable */
require("./LandingPage.module.css");
const styles = {
  landingPage: 'landingPage_20a6c3f4',
  container: 'container_20a6c3f4',
  row: 'row_20a6c3f4',
  column: 'column_20a6c3f4',
  'ms-Grid': 'ms-Grid_20a6c3f4',
  title: 'title_20a6c3f4',
  subTitle: 'subTitle_20a6c3f4',
  description: 'description_20a6c3f4',
  button: 'button_20a6c3f4',
  label: 'label_20a6c3f4',
  cbutton: 'cbutton_20a6c3f4',
  ebutton: 'ebutton_20a6c3f4'
};

export default styles;
/* tslint:enable */