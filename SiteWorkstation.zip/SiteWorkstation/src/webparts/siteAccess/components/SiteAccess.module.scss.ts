/* tslint:disable */
require("./SiteAccess.module.css");
const styles = {
  siteandWf: 'siteandWf_e2ccbad2',
  container: 'container_e2ccbad2',
  row: 'row_e2ccbad2',
  column: 'column_e2ccbad2',
  'ms-Grid': 'ms-Grid_e2ccbad2',
  title: 'title_e2ccbad2',
  subTitle: 'subTitle_e2ccbad2',
  description: 'description_e2ccbad2',
  button: 'button_e2ccbad2',
  label: 'label_e2ccbad2',
  heading: 'heading_e2ccbad2',
  dialog: 'dialog_e2ccbad2',
  Skillbutton: 'Skillbutton_e2ccbad2'
};

export default styles;
/* tslint:enable */