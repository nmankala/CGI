declare interface ISiteAccessWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SiteAccessWebPartStrings' {
  const strings: ISiteAccessWebPartStrings;
  export = strings;
}
