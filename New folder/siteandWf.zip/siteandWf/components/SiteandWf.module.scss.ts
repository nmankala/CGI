/* tslint:disable */
require("./SiteandWf.module.css");
const styles = {
  siteandWf: 'siteandWf_d5a4a24d',
  container: 'container_d5a4a24d',
  row: 'row_d5a4a24d',
  column: 'column_d5a4a24d',
  'ms-Grid': 'ms-Grid_d5a4a24d',
  title: 'title_d5a4a24d',
  subTitle: 'subTitle_d5a4a24d',
  description: 'description_d5a4a24d',
  button: 'button_d5a4a24d',
  label: 'label_d5a4a24d',
  heading: 'heading_d5a4a24d'
};

export default styles;
/* tslint:enable */