declare interface ISiteandWfWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SiteandWfWebPartStrings' {
  const strings: ISiteandWfWebPartStrings;
  export = strings;
}
