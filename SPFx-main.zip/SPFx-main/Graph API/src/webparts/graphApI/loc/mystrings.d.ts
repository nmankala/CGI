declare interface IGraphApIWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphApIWebPartStrings' {
  const strings: IGraphApIWebPartStrings;
  export = strings;
}
