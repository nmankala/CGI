import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';

export interface Icalendardemostate{
    events: MicrosoftGraph.Event[];
}