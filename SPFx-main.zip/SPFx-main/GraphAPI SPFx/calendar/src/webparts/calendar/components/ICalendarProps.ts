

import { WebPartContext } from '@microsoft/sp-webpart-base' 
export interface ICalendarProps {
  description: string;
  context:WebPartContext;
}
