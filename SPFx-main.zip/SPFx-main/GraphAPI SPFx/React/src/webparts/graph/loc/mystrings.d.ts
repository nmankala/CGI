declare interface IGraphWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphWebPartStrings' {
  const strings: IGraphWebPartStrings;
  export = strings;
}
