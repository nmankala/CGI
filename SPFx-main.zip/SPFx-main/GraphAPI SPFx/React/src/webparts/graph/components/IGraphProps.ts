export interface IGraphProps {
  description: string;
}
