declare interface IGraphApiWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphApiWebPartStrings' {
  const strings: IGraphApiWebPartStrings;
  export = strings;
}
