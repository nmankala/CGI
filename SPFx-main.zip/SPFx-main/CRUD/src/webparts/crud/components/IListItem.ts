export interface IListitem{
Id:number;
Title:string;
Name:string;
}