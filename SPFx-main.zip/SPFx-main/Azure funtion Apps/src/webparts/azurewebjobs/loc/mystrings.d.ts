declare interface IAzurewebjobsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AzurewebjobsWebPartStrings' {
  const strings: IAzurewebjobsWebPartStrings;
  export = strings;
}
