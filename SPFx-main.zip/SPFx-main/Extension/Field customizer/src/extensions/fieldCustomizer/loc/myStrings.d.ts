declare interface IFieldCustomizerFieldCustomizerStrings {
  Title: string;
}

declare module 'FieldCustomizerFieldCustomizerStrings' {
  const strings: IFieldCustomizerFieldCustomizerStrings;
  export = strings;
}
