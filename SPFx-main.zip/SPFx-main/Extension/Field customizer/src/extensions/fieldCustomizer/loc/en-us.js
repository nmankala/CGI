define([], function() {
  return {
    "Title": "FieldCustomizerFieldCustomizer"
  }
});