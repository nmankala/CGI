declare interface IAppCustomizerApplicationCustomizerStrings {
  Title: string;
}

declare module 'AppCustomizerApplicationCustomizerStrings' {
  const strings: IAppCustomizerApplicationCustomizerStrings;
  export = strings;
}
