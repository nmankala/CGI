define([], function() {
  return {
    "Title": "AppCustomizerApplicationCustomizer"
  }
});