export interface ICrudProps {
  description: string;
}
