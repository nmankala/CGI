export interface IReactChatbotProps {
  description: string;
  eventHandler: Event;
}
