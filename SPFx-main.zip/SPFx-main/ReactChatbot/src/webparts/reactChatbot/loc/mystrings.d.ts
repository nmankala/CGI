declare interface IReactChatbotWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactChatbotWebPartStrings' {
  const strings: IReactChatbotWebPartStrings;
  export = strings;
}
