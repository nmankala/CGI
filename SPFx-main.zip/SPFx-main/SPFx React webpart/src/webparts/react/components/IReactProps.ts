export interface IReactProps {
  description1: string;
  mytest1:string;
}
