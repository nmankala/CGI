declare interface IOfficefabricWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OfficefabricWebPartStrings' {
  const strings: IOfficefabricWebPartStrings;
  export = strings;
}
