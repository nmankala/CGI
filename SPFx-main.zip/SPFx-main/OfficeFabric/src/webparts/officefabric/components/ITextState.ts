export interface IComponentState {  
    userName: string;  
} 