export interface IOfficefabricProps {
  description: string;
}
