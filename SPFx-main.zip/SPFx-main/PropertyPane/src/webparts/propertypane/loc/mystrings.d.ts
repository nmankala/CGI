declare interface IPropertypaneWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PropertypaneWebPartStrings' {
  const strings: IPropertypaneWebPartStrings;
  export = strings;
}
