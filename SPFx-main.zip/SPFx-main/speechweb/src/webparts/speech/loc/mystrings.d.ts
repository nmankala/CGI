declare interface ISpeechWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpeechWebPartStrings' {
  const strings: ISpeechWebPartStrings;
  export = strings;
}
