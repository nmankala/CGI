export interface ISpeechProps {
  description: string;
}
