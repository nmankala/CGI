export interface ISpfxTexttospeakState {
    textcontent : String;
  }